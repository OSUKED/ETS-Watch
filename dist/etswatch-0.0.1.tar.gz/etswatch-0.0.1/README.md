# ETS Watch

This repository includes code for retrieving the latest data on the EU ETS market

Last updated: 2021-04-28 07:51

<br>

### Long-Term Average Price

![Long-term average](img/long_term_avg.png)

<br>

### Candle-Stick Chart for Last 8-Weeks

![Open, High, Low, Close & Volume](img/ohlc_vol.png)
